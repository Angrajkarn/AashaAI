from fastapi import APIRouter, HTTPException, UploadFile, File, Depends
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import Session
from fastapi import Form
from ..database import SessionLocal
from ..models import TriageRecord



router = APIRouter(
    prefix="/api/triage",
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class SymptomRequest(BaseModel):
    symptoms: str
    patient_id: Optional[str] = None
    age: Optional[int] = None

class TriageResponse(BaseModel):
    diagnosis: str
    confidence: float
    urgent: bool
    recommendation: str
    referral_needed: bool

from ..services.ai.engine import ai_engine
from ..services.ai.schemas import AIProviderRequest
from ..services.websocket_manager import manager

@router.post("/analyze", response_model=TriageResponse)
async def analyze_symptoms(request: SymptomRequest, db: Session = Depends(get_db)):
    """
    Analyze text-based symptoms to provide a preliminary diagnosis using AWS Bedrock.
    """
    if not request.symptoms:
        raise HTTPException(status_code=400, detail="Symptoms cannot be empty")
    
    # Use Enterprise AIEngine (Text Only via standard Request)
    ai_request = AIProviderRequest(symptoms=request.symptoms, age=request.age or 30)
    result = ai_engine.analyze_triage(ai_request)
    
    # Save to DB
    record = TriageRecord(
        patient_id=request.patient_id, # Can be None for new walk-ins, or we need to handle it.
        symptoms=request.symptoms,
        diagnosis=result["diagnosis"],
        confidence=result["confidence"],
        urgent=result["urgent"],
        recommendation=result["recommendation"],
        referral_needed=result["referral_needed"]
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    
    # Broadcast real-time urgent alert to the frontend if risk is high
    if result["urgent"]:
        import asyncio
        asyncio.create_task(manager.broadcast({
            "type": "NEW_HIGH_RISK_PATIENT",
            "patient_id": request.patient_id,
            "diagnosis": result["diagnosis"],
            "recommendation": result["recommendation"]
        }))
    
    return result

@router.post("/voice")
async def analyze_voice(file: UploadFile = File(...)):
    """
    Upload an audio file for speech-to-text and symptom analysis.
    (Simulated for now)
    """
    # 1. Save file locally (optional)
    # 2. Transcribe using Whisper (Mocked: "High fever and cough")
    mock_transcription = "High fever and severe cough"
    
    # 3. Analyze using Enterprise AIEngine
    ai_request = AIProviderRequest(symptoms=mock_transcription, age=30)
    result = ai_engine.analyze_triage(ai_request)
    return {
        "transcription": mock_transcription,
        "analysis": result
    }

import os
import shutil
import uuid

# Multimodal endpoint
@router.post("/multimodal")
async def analyze_multimodal(
    symptoms: str = Form(...),
    age: int = Form(30),
    patient_id: Optional[int] = Form(None),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    """
    Enterprise-level multimodal triage endpoint.
    Processes clinical text symptoms along with optional images (wounds, rashes) using Claude 3 Vision.
    Enforces WHO guidelines for the output.
    """
    if not symptoms:
        raise HTTPException(status_code=400, detail="Symptoms cannot be empty")
        
    image_bytes = None
    image_mime_type = "image/jpeg"
    saved_image_path = None
    
    # Process image if uploaded
    if image:
        try:
            image_bytes = await image.read()
            image_mime_type = image.content_type
            
            # Save file locally for reference (in production this would be S3)
            os.makedirs("uploads", exist_ok=True)
            saved_image_path = f"uploads/{uuid.uuid4()}_{image.filename}"
            
            with open(saved_image_path, "wb") as f:
                f.write(image_bytes)
                
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Image processing failed: {str(e)}")

    # 1. Analyze via Enterprise AIEngine
    ai_request = AIProviderRequest(
        symptoms=symptoms, 
        age=age, 
        image_bytes=image_bytes, 
        image_mime_type=image_mime_type
    )
    result = ai_engine.analyze_triage(ai_request)
    
    # 2. Save structurally to Database
    record = TriageRecord(
        patient_id=patient_id,
        symptoms=symptoms,
        diagnosis=result.get("diagnosis", "Unknown"),
        confidence=result.get("confidence", 0.0),
        urgent=result.get("urgent", False),
        recommendation=result.get("recommendation", "N/A"),
        referral_needed=result.get("referral_needed", False),
        image_url=saved_image_path
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    
    # 3. Real-time WebSocket Broadcast for Critical Cases (WHO Red/Yellow)
    if result.get("urgent") or result.get("referral_needed"):
        import asyncio
        asyncio.create_task(manager.broadcast({
            "type": "NEW_HIGH_RISK_PATIENT",
            "patient_id": patient_id,
            "diagnosis": result.get("diagnosis"),
            "recommendation": result.get("recommendation"),
            "image_url": saved_image_path
        }))
        
    return result

