export const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function login(biometricId: string) {
  const res = await fetch(`${API_BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ biometric_id: biometricId }),
  });
  if (!res.ok) throw new Error("Login failed");
  return res.json();
}

export async function getPatients() {
  const res = await fetch(`${API_BASE}/api/patients/`);
  if (!res.ok) throw new Error("Failed to fetch patients");
  return res.json();
}

export async function analyzeSymptoms(symptoms: string) {
  const res = await fetch(`${API_BASE}/api/triage/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ symptoms }),
  });
  if (!res.ok) throw new Error("Analysis failed");
  return res.json();
}

export async function analyzeMultimodal(symptoms: string, imageBlob?: Blob | null, age: number = 30) {
  // If no image is provided, fallback to the lightweight endpoint
  if (!imageBlob) {
    return analyzeSymptoms(symptoms);
  }

  const formData = new FormData();
  formData.append("symptoms", symptoms);
  formData.append("age", age.toString());
  formData.append("image", imageBlob, "captured_condition.jpg");

  const res = await fetch(`${API_BASE}/api/triage/multimodal`, {
    method: "POST",
    // Do NOT set Content-Type header manually when using FormData
    body: formData,
  });
  
  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Multimodal Analysis failed: ${res.status} ${errorText}`);
  }
  
  return res.json();
}
